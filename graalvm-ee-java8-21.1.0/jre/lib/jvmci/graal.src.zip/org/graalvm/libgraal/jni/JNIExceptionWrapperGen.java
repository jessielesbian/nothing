// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: JNIExceptionWrapper.java
// Generated-by: org.graalvm.libgraal.jni.processor.JNIFromLibGraalProcessor
package org.graalvm.libgraal.jni;

import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.CreateException;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.UpdateStackTrace;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.GetThrowableMessage;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.GetClassName;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.GetStackTrace;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.GetStackTraceElementClassName;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.GetStackTraceElementMethodName;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.GetStackTraceElementFileName;
import static org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id.GetStackTraceElementLineNumber;

import org.graalvm.nativeimage.StackValue;
import org.graalvm.libgraal.jni.JNI.JNIEnv;
import org.graalvm.libgraal.jni.JNI.JValue;
import org.graalvm.libgraal.jni.JNI.JObject;

final class JNIExceptionWrapperGen {

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callCreateException(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, CreateException, args);
    }

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callUpdateStackTrace(JNIEnv env, JObject p0, JObject p1) {
        JValue args = StackValue.get(2, JValue.class);
        args.addressOf(0).setJObject(p0);
        args.addressOf(1).setJObject(p1);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, UpdateStackTrace, args);
    }

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callGetThrowableMessage(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, GetThrowableMessage, args);
    }

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callGetClassName(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, GetClassName, args);
    }

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callGetStackTrace(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, GetStackTrace, args);
    }

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callGetStackTraceElementClassName(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, GetStackTraceElementClassName, args);
    }

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callGetStackTraceElementMethodName(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, GetStackTraceElementMethodName, args);
    }

    @SuppressWarnings("unchecked")
    static <T extends JObject> T callGetStackTraceElementFileName(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return (T) JNIFromLibGraalCalls.INSTANCE.callJObject(env, GetStackTraceElementFileName, args);
    }

    static int callGetStackTraceElementLineNumber(JNIEnv env, JObject p0) {
        JValue args = StackValue.get(1, JValue.class);
        args.addressOf(0).setJObject(p0);
        return JNIFromLibGraalCalls.INSTANCE.callInt(env, GetStackTraceElementLineNumber, args);
    }
}
