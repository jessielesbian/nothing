// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: org.graalvm.libgraal.jni.JNIExceptionWrapper.java
// Generated-by: org.graalvm.libgraal.jni.processor.FromLibGraalEntryPointsResolverProcessor
package org.graalvm.libgraal.jni;

import org.graalvm.libgraal.jni.JNI.JClass;
import org.graalvm.libgraal.jni.JNI.JNIEnv;
import org.graalvm.libgraal.jni.annotation.JNIFromLibGraal.Id;

class JNIFromLibGraalCalls extends FromLibGraalCalls<Id> {

    static final JNIFromLibGraalCalls INSTANCE = new JNIFromLibGraalCalls();

    private JNIFromLibGraalCalls() {
        super(Id.class);
    }

    @Override
    protected JClass resolvePeer(JNIEnv env) {
        return JNIExceptionWrapper.getHotSpotEntryPoints(env);
    }
}
