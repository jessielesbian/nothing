// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: GraalOptions.java
package org.graalvm.compiler.core.common;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class GraalOptions_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "AOTVerifyOops": {
            return OptionDescriptor.create(
                /*name*/ "AOTVerifyOops",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Generate verify oop checks in AOT code",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "AOTVerifyOops",
                /*option*/ GraalOptions.AOTVerifyOops,
                /*deprecated*/ false);
        }
        case "AlwaysInlineVTableStubs": {
            return OptionDescriptor.create(
                /*name*/ "AlwaysInlineVTableStubs",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "AlwaysInlineVTableStubs",
                /*option*/ GraalOptions.AlwaysInlineVTableStubs,
                /*deprecated*/ false);
        }
        case "CanOmitFrame": {
            return OptionDescriptor.create(
                /*name*/ "CanOmitFrame",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "CanOmitFrame",
                /*option*/ GraalOptions.CanOmitFrame,
                /*deprecated*/ false);
        }
        case "ConditionalElimination": {
            return OptionDescriptor.create(
                /*name*/ "ConditionalElimination",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "ConditionalElimination",
                /*option*/ GraalOptions.ConditionalElimination,
                /*deprecated*/ false);
        }
        case "ConditionalEliminationMaxIterations": {
            return OptionDescriptor.create(
                /*name*/ "ConditionalEliminationMaxIterations",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Integer.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "ConditionalEliminationMaxIterations",
                /*option*/ GraalOptions.ConditionalEliminationMaxIterations,
                /*deprecated*/ false);
        }
        case "DeoptALot": {
            return OptionDescriptor.create(
                /*name*/ "DeoptALot",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "DeoptALot",
                /*option*/ GraalOptions.DeoptALot,
                /*deprecated*/ false);
        }
        case "DeoptsToDisableOptimisticOptimization": {
            return OptionDescriptor.create(
                /*name*/ "DeoptsToDisableOptimisticOptimization",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "DeoptsToDisableOptimisticOptimization",
                /*option*/ GraalOptions.DeoptsToDisableOptimisticOptimization,
                /*deprecated*/ false);
        }
        case "EagerSnippets": {
            return OptionDescriptor.create(
                /*name*/ "EagerSnippets",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Eagerly construct extra snippet info.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "EagerSnippets",
                /*option*/ GraalOptions.EagerSnippets,
                /*deprecated*/ false);
        }
        case "EmitStringSubstitutions": {
            return OptionDescriptor.create(
                /*name*/ "EmitStringSubstitutions",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Emit substitutions for String methods",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "EmitStringSubstitutions",
                /*option*/ GraalOptions.EmitStringSubstitutions,
                /*deprecated*/ false);
        }
        case "EscapeAnalysisIterations": {
            return OptionDescriptor.create(
                /*name*/ "EscapeAnalysisIterations",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Integer.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "EscapeAnalysisIterations",
                /*option*/ GraalOptions.EscapeAnalysisIterations,
                /*deprecated*/ false);
        }
        case "EscapeAnalysisLoopCutoff": {
            return OptionDescriptor.create(
                /*name*/ "EscapeAnalysisLoopCutoff",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Integer.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "EscapeAnalysisLoopCutoff",
                /*option*/ GraalOptions.EscapeAnalysisLoopCutoff,
                /*deprecated*/ false);
        }
        case "EscapeAnalyzeOnly": {
            return OptionDescriptor.create(
                /*name*/ "EscapeAnalyzeOnly",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ String.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "EscapeAnalyzeOnly",
                /*option*/ GraalOptions.EscapeAnalyzeOnly,
                /*deprecated*/ false);
        }
        case "FullUnroll": {
            return OptionDescriptor.create(
                /*name*/ "FullUnroll",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "FullUnroll",
                /*option*/ GraalOptions.FullUnroll,
                /*deprecated*/ false);
        }
        case "GCDebugStartCycle": {
            return OptionDescriptor.create(
                /*name*/ "GCDebugStartCycle",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Integer.class,
                /*help*/ "Start tracing compiled GC barriers after N garbage collections (disabled if N <= 0).",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "GCDebugStartCycle",
                /*option*/ GraalOptions.GCDebugStartCycle,
                /*deprecated*/ false);
        }
        case "GenLoopSafepoints": {
            return OptionDescriptor.create(
                /*name*/ "GenLoopSafepoints",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "GenLoopSafepoints",
                /*option*/ GraalOptions.GenLoopSafepoints,
                /*deprecated*/ false);
        }
        case "GeneratePIC": {
            return OptionDescriptor.create(
                /*name*/ "GeneratePIC",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Generate position independent code",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "GeneratePIC",
                /*option*/ GraalOptions.GeneratePIC,
                /*deprecated*/ false);
        }
        case "GuardPriorities": {
            return OptionDescriptor.create(
                /*name*/ "GuardPriorities",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "GuardPriorities",
                /*option*/ GraalOptions.GuardPriorities,
                /*deprecated*/ false);
        }
        case "HotSpotPrintInlining": {
            return OptionDescriptor.create(
                /*name*/ "HotSpotPrintInlining",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Print inlining optimizations",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "HotSpotPrintInlining",
                /*option*/ GraalOptions.HotSpotPrintInlining,
                /*deprecated*/ false);
        }
        case "ImmutableCode": {
            return OptionDescriptor.create(
                /*name*/ "ImmutableCode",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Try to avoid emitting code where patching is required",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "ImmutableCode",
                /*option*/ GraalOptions.ImmutableCode,
                /*deprecated*/ false);
        }
        case "InlineEverything": {
            return OptionDescriptor.create(
                /*name*/ "InlineEverything",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "InlineEverything",
                /*option*/ GraalOptions.InlineEverything,
                /*deprecated*/ false);
        }
        case "InlineMegamorphicCalls": {
            return OptionDescriptor.create(
                /*name*/ "InlineMegamorphicCalls",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Inline calls with megamorphic type profile (i.e., not all types could be recorded).",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "InlineMegamorphicCalls",
                /*option*/ GraalOptions.InlineMegamorphicCalls,
                /*deprecated*/ false);
        }
        case "InlineMonomorphicCalls": {
            return OptionDescriptor.create(
                /*name*/ "InlineMonomorphicCalls",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Inline calls with monomorphic type profile.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "InlineMonomorphicCalls",
                /*option*/ GraalOptions.InlineMonomorphicCalls,
                /*deprecated*/ false);
        }
        case "InlinePolymorphicCalls": {
            return OptionDescriptor.create(
                /*name*/ "InlinePolymorphicCalls",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Inline calls with polymorphic type profile.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "InlinePolymorphicCalls",
                /*option*/ GraalOptions.InlinePolymorphicCalls,
                /*deprecated*/ false);
        }
        case "InlineVTableStubs": {
            return OptionDescriptor.create(
                /*name*/ "InlineVTableStubs",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "InlineVTableStubs",
                /*option*/ GraalOptions.InlineVTableStubs,
                /*deprecated*/ false);
        }
        case "Intrinsify": {
            return OptionDescriptor.create(
                /*name*/ "Intrinsify",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Use compiler intrinsifications.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "Intrinsify",
                /*option*/ GraalOptions.Intrinsify,
                /*deprecated*/ false);
        }
        case "LimitInlinedInvokes": {
            return OptionDescriptor.create(
                /*name*/ "LimitInlinedInvokes",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Double.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "LimitInlinedInvokes",
                /*option*/ GraalOptions.LimitInlinedInvokes,
                /*deprecated*/ false);
        }
        case "LoopHeaderAlignment": {
            return OptionDescriptor.create(
                /*name*/ "LoopHeaderAlignment",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "Alignment in bytes for loop header blocks.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "LoopHeaderAlignment",
                /*option*/ GraalOptions.LoopHeaderAlignment,
                /*deprecated*/ false);
        }
        case "LoopMaxUnswitch": {
            return OptionDescriptor.create(
                /*name*/ "LoopMaxUnswitch",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "LoopMaxUnswitch",
                /*option*/ GraalOptions.LoopMaxUnswitch,
                /*deprecated*/ false);
        }
        case "LoopPeeling": {
            return OptionDescriptor.create(
                /*name*/ "LoopPeeling",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "LoopPeeling",
                /*option*/ GraalOptions.LoopPeeling,
                /*deprecated*/ false);
        }
        case "LoopPredication": {
            return OptionDescriptor.create(
                /*name*/ "LoopPredication",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "LoopPredication",
                /*option*/ GraalOptions.LoopPredication,
                /*deprecated*/ false);
        }
        case "LoopPredicationMainPath": {
            return OptionDescriptor.create(
                /*name*/ "LoopPredicationMainPath",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "LoopPredicationMainPath",
                /*option*/ GraalOptions.LoopPredicationMainPath,
                /*deprecated*/ false);
        }
        case "LoopUnswitch": {
            return OptionDescriptor.create(
                /*name*/ "LoopUnswitch",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "LoopUnswitch",
                /*option*/ GraalOptions.LoopUnswitch,
                /*deprecated*/ false);
        }
        case "MatchExpressions": {
            return OptionDescriptor.create(
                /*name*/ "MatchExpressions",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Allow backend to match complex expressions.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MatchExpressions",
                /*option*/ GraalOptions.MatchExpressions,
                /*deprecated*/ false);
        }
        case "MaximumDesiredSize": {
            return OptionDescriptor.create(
                /*name*/ "MaximumDesiredSize",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ Integer.class,
                /*help*/ "Maximum desired size of the compiler graph in nodes.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MaximumDesiredSize",
                /*option*/ GraalOptions.MaximumDesiredSize,
                /*deprecated*/ false);
        }
        case "MaximumEscapeAnalysisArrayLength": {
            return OptionDescriptor.create(
                /*name*/ "MaximumEscapeAnalysisArrayLength",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "The maximum length of an array that will be escape analyzed.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MaximumEscapeAnalysisArrayLength",
                /*option*/ GraalOptions.MaximumEscapeAnalysisArrayLength,
                /*deprecated*/ false);
        }
        case "MaximumInliningSize": {
            return OptionDescriptor.create(
                /*name*/ "MaximumInliningSize",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "Inlining is explored up to this number of nodes in the graph for each call site.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MaximumInliningSize",
                /*option*/ GraalOptions.MaximumInliningSize,
                /*deprecated*/ false);
        }
        case "MaximumRecursiveInlining": {
            return OptionDescriptor.create(
                /*name*/ "MaximumRecursiveInlining",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "Maximum level of recursive inlining.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MaximumRecursiveInlining",
                /*option*/ GraalOptions.MaximumRecursiveInlining,
                /*deprecated*/ false);
        }
        case "MegamorphicInliningMinMethodProbability": {
            return OptionDescriptor.create(
                /*name*/ "MegamorphicInliningMinMethodProbability",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Double.class,
                /*help*/ "Minimum probability for methods to be inlined for megamorphic type profiles.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MegamorphicInliningMinMethodProbability",
                /*option*/ GraalOptions.MegamorphicInliningMinMethodProbability,
                /*deprecated*/ false);
        }
        case "MinimalBulkZeroingSize": {
            return OptionDescriptor.create(
                /*name*/ "MinimalBulkZeroingSize",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "If applicable, use bulk zeroing instructions when the zeroing size in bytes exceeds this threshold.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MinimalBulkZeroingSize",
                /*option*/ GraalOptions.MinimalBulkZeroingSize,
                /*deprecated*/ false);
        }
        case "MinimumPeelFrequency": {
            return OptionDescriptor.create(
                /*name*/ "MinimumPeelFrequency",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Float.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "MinimumPeelFrequency",
                /*option*/ GraalOptions.MinimumPeelFrequency,
                /*deprecated*/ false);
        }
        case "OmitHotExceptionStacktrace": {
            return OptionDescriptor.create(
                /*name*/ "OmitHotExceptionStacktrace",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OmitHotExceptionStacktrace",
                /*option*/ GraalOptions.OmitHotExceptionStacktrace,
                /*deprecated*/ false);
        }
        case "OptAssumptions": {
            return OptionDescriptor.create(
                /*name*/ "OptAssumptions",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptAssumptions",
                /*option*/ GraalOptions.OptAssumptions,
                /*deprecated*/ false);
        }
        case "OptConvertDeoptsToGuards": {
            return OptionDescriptor.create(
                /*name*/ "OptConvertDeoptsToGuards",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptConvertDeoptsToGuards",
                /*option*/ GraalOptions.OptConvertDeoptsToGuards,
                /*deprecated*/ false);
        }
        case "OptDeoptimizationGrouping": {
            return OptionDescriptor.create(
                /*name*/ "OptDeoptimizationGrouping",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptDeoptimizationGrouping",
                /*option*/ GraalOptions.OptDeoptimizationGrouping,
                /*deprecated*/ false);
        }
        case "OptDevirtualizeInvokesOptimistically": {
            return OptionDescriptor.create(
                /*name*/ "OptDevirtualizeInvokesOptimistically",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptDevirtualizeInvokesOptimistically",
                /*option*/ GraalOptions.OptDevirtualizeInvokesOptimistically,
                /*deprecated*/ false);
        }
        case "OptEliminateGuards": {
            return OptionDescriptor.create(
                /*name*/ "OptEliminateGuards",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptEliminateGuards",
                /*option*/ GraalOptions.OptEliminateGuards,
                /*deprecated*/ false);
        }
        case "OptFloatingReads": {
            return OptionDescriptor.create(
                /*name*/ "OptFloatingReads",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptFloatingReads",
                /*option*/ GraalOptions.OptFloatingReads,
                /*deprecated*/ false);
        }
        case "OptImplicitNullChecks": {
            return OptionDescriptor.create(
                /*name*/ "OptImplicitNullChecks",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptImplicitNullChecks",
                /*option*/ GraalOptions.OptImplicitNullChecks,
                /*deprecated*/ false);
        }
        case "OptReadElimination": {
            return OptionDescriptor.create(
                /*name*/ "OptReadElimination",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptReadElimination",
                /*option*/ GraalOptions.OptReadElimination,
                /*deprecated*/ false);
        }
        case "OptScheduleOutOfLoops": {
            return OptionDescriptor.create(
                /*name*/ "OptScheduleOutOfLoops",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "OptScheduleOutOfLoops",
                /*option*/ GraalOptions.OptScheduleOutOfLoops,
                /*deprecated*/ false);
        }
        case "PartialEscapeAnalysis": {
            return OptionDescriptor.create(
                /*name*/ "PartialEscapeAnalysis",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "PartialEscapeAnalysis",
                /*option*/ GraalOptions.PartialEscapeAnalysis,
                /*deprecated*/ false);
        }
        case "PartialUnroll": {
            return OptionDescriptor.create(
                /*name*/ "PartialUnroll",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "PartialUnroll",
                /*option*/ GraalOptions.PartialUnroll,
                /*deprecated*/ false);
        }
        case "PrintProfilingInformation": {
            return OptionDescriptor.create(
                /*name*/ "PrintProfilingInformation",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Print profiling information when parsing a method's bytecode",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "PrintProfilingInformation",
                /*option*/ GraalOptions.PrintProfilingInformation,
                /*deprecated*/ false);
        }
        case "RawConditionalElimination": {
            return OptionDescriptor.create(
                /*name*/ "RawConditionalElimination",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "RawConditionalElimination",
                /*option*/ GraalOptions.RawConditionalElimination,
                /*deprecated*/ false);
        }
        case "ReadEliminationMaxLoopVisits": {
            return OptionDescriptor.create(
                /*name*/ "ReadEliminationMaxLoopVisits",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Integer.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "ReadEliminationMaxLoopVisits",
                /*option*/ GraalOptions.ReadEliminationMaxLoopVisits,
                /*deprecated*/ false);
        }
        case "ReassociateExpressions": {
            return OptionDescriptor.create(
                /*name*/ "ReassociateExpressions",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Re-associate loop invariants and constants.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "ReassociateExpressions",
                /*option*/ GraalOptions.ReassociateExpressions,
                /*deprecated*/ false);
        }
        case "RegisterPressure": {
            return OptionDescriptor.create(
                /*name*/ "RegisterPressure",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ String.class,
                /*help*/ "Comma separated list of registers that register allocation is limited to.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "RegisterPressure",
                /*option*/ GraalOptions.RegisterPressure,
                /*deprecated*/ false);
        }
        case "RemoveNeverExecutedCode": {
            return OptionDescriptor.create(
                /*name*/ "RemoveNeverExecutedCode",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "RemoveNeverExecutedCode",
                /*option*/ GraalOptions.RemoveNeverExecutedCode,
                /*deprecated*/ false);
        }
        case "ReplaceInputsWithConstantsBasedOnStamps": {
            return OptionDescriptor.create(
                /*name*/ "ReplaceInputsWithConstantsBasedOnStamps",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "ReplaceInputsWithConstantsBasedOnStamps",
                /*option*/ GraalOptions.ReplaceInputsWithConstantsBasedOnStamps,
                /*deprecated*/ false);
        }
        case "SmallCompiledLowLevelGraphSize": {
            return OptionDescriptor.create(
                /*name*/ "SmallCompiledLowLevelGraphSize",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "If the previous low-level graph size of the method exceeds the threshold, it is not inlined.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "SmallCompiledLowLevelGraphSize",
                /*option*/ GraalOptions.SmallCompiledLowLevelGraphSize,
                /*deprecated*/ false);
        }
        case "SnippetCounters": {
            return OptionDescriptor.create(
                /*name*/ "SnippetCounters",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Enable counters for various paths in snippets.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "SnippetCounters",
                /*option*/ GraalOptions.SnippetCounters,
                /*deprecated*/ false);
        }
        case "StressExplicitExceptionCode": {
            return OptionDescriptor.create(
                /*name*/ "StressExplicitExceptionCode",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Stress the code emitting explicit exception throwing code.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "StressExplicitExceptionCode",
                /*option*/ GraalOptions.StressExplicitExceptionCode,
                /*deprecated*/ false);
        }
        case "StressInvokeWithExceptionNode": {
            return OptionDescriptor.create(
                /*name*/ "StressInvokeWithExceptionNode",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Stress the code emitting invokes with explicit exception edges.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "StressInvokeWithExceptionNode",
                /*option*/ GraalOptions.StressInvokeWithExceptionNode,
                /*deprecated*/ false);
        }
        case "StressTestEarlyReads": {
            return OptionDescriptor.create(
                /*name*/ "StressTestEarlyReads",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Stress the code by emitting reads at earliest instead of latest point.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "StressTestEarlyReads",
                /*option*/ GraalOptions.StressTestEarlyReads,
                /*deprecated*/ false);
        }
        case "StringIndexOfLimit": {
            return OptionDescriptor.create(
                /*name*/ "StringIndexOfLimit",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "String.indexOf invocations will be evaluated at compile time if the receiver is a constant and its length is lower than this value.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "StringIndexOfLimit",
                /*option*/ GraalOptions.StringIndexOfLimit,
                /*deprecated*/ false);
        }
        case "SupportJsrBytecodes": {
            return OptionDescriptor.create(
                /*name*/ "SupportJsrBytecodes",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "SupportJsrBytecodes",
                /*option*/ GraalOptions.SupportJsrBytecodes,
                /*deprecated*/ false);
        }
        case "TraceEscapeAnalysis": {
            return OptionDescriptor.create(
                /*name*/ "TraceEscapeAnalysis",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "TraceEscapeAnalysis",
                /*option*/ GraalOptions.TraceEscapeAnalysis,
                /*deprecated*/ false);
        }
        case "TraceInlining": {
            return OptionDescriptor.create(
                /*name*/ "TraceInlining",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Enable tracing of inlining decisions.",
                /*extraHelp*/ new String[] {
                         "Output format:",
                         "  compilation of 'Signature of the compilation root method':",
                         "    at 'Signature of the root method' ['Bytecode index']: <'Phase'> 'Child method signature': 'Decision made about this callsite'",
                         "      at 'Signature of the child method' ['Bytecode index']: ",
                         "         |--<'Phase 1'> 'Grandchild method signature': 'First decision made about this callsite'",
                         "         \\--<'Phase 2'> 'Grandchild method signature': 'Second decision made about this callsite'",
                         "      at 'Signature of the child method' ['Bytecode index']: <'Phase'> 'Another grandchild method signature': 'The only decision made about this callsite.'",
                              },
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "TraceInlining",
                /*option*/ GraalOptions.TraceInlining,
                /*deprecated*/ false);
        }
        case "TraceInliningForStubsAndSnippets": {
            return OptionDescriptor.create(
                /*name*/ "TraceInliningForStubsAndSnippets",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Enable inlining decision tracing in stubs and snippets.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "TraceInliningForStubsAndSnippets",
                /*option*/ GraalOptions.TraceInliningForStubsAndSnippets,
                /*deprecated*/ false);
        }
        case "TrackNodeInsertion": {
            return OptionDescriptor.create(
                /*name*/ "TrackNodeInsertion",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Track source stack trace where a node was inserted into the graph.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "TrackNodeInsertion",
                /*option*/ GraalOptions.TrackNodeInsertion,
                /*deprecated*/ false);
        }
        case "TrackNodeSourcePosition": {
            return OptionDescriptor.create(
                /*name*/ "TrackNodeSourcePosition",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Track the NodeSourcePosition.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "TrackNodeSourcePosition",
                /*option*/ GraalOptions.TrackNodeSourcePosition,
                /*deprecated*/ false);
        }
        case "TrivialInliningSize": {
            return OptionDescriptor.create(
                /*name*/ "TrivialInliningSize",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Integer.class,
                /*help*/ "Graphs with less than this number of nodes are trivial and therefore always inlined.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "TrivialInliningSize",
                /*option*/ GraalOptions.TrivialInliningSize,
                /*deprecated*/ false);
        }
        case "UseEncodedGraphs": {
            return OptionDescriptor.create(
                /*name*/ "UseEncodedGraphs",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Encode and decode snippets and substitutions before parsing to test libgraal code path. This option is ignored in the context of libgraal.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "UseEncodedGraphs",
                /*option*/ GraalOptions.UseEncodedGraphs,
                /*deprecated*/ false);
        }
        case "UseExceptionProbability": {
            return OptionDescriptor.create(
                /*name*/ "UseExceptionProbability",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "UseExceptionProbability",
                /*option*/ GraalOptions.UseExceptionProbability,
                /*deprecated*/ false);
        }
        case "UseGraalStubs": {
            return OptionDescriptor.create(
                /*name*/ "UseGraalStubs",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Use Graal-generated stubs for complicated LIR operations instead of embedding all the emitted code.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "UseGraalStubs",
                /*option*/ GraalOptions.UseGraalStubs,
                /*deprecated*/ false);
        }
        case "UseLoopLimitChecks": {
            return OptionDescriptor.create(
                /*name*/ "UseLoopLimitChecks",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "UseLoopLimitChecks",
                /*option*/ GraalOptions.UseLoopLimitChecks,
                /*deprecated*/ false);
        }
        case "UseSnippetGraphCache": {
            return OptionDescriptor.create(
                /*name*/ "UseSnippetGraphCache",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Use a cache for snippet graphs.",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "UseSnippetGraphCache",
                /*option*/ GraalOptions.UseSnippetGraphCache,
                /*deprecated*/ false);
        }
        case "UseTypeCheckHints": {
            return OptionDescriptor.create(
                /*name*/ "UseTypeCheckHints",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "UseTypeCheckHints",
                /*option*/ GraalOptions.UseTypeCheckHints,
                /*deprecated*/ false);
        }
        case "VerifyHeapAtReturn": {
            return OptionDescriptor.create(
                /*name*/ "VerifyHeapAtReturn",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Perform platform dependent validation of the Java heap at returns",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "VerifyHeapAtReturn",
                /*option*/ GraalOptions.VerifyHeapAtReturn,
                /*deprecated*/ false);
        }
        case "VerifyPhases": {
            return OptionDescriptor.create(
                /*name*/ "VerifyPhases",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "VerifyPhases",
                /*option*/ GraalOptions.VerifyPhases,
                /*deprecated*/ false);
        }
        case "ZapStackOnMethodEntry": {
            return OptionDescriptor.create(
                /*name*/ "ZapStackOnMethodEntry",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "",
                /*declaringClass*/ GraalOptions.class,
                /*fieldName*/ "ZapStackOnMethodEntry",
                /*option*/ GraalOptions.ZapStackOnMethodEntry,
                /*deprecated*/ false);
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<OptionDescriptor>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 81;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("AOTVerifyOops");
                    case 1: return get("AlwaysInlineVTableStubs");
                    case 2: return get("CanOmitFrame");
                    case 3: return get("ConditionalElimination");
                    case 4: return get("ConditionalEliminationMaxIterations");
                    case 5: return get("DeoptALot");
                    case 6: return get("DeoptsToDisableOptimisticOptimization");
                    case 7: return get("EagerSnippets");
                    case 8: return get("EmitStringSubstitutions");
                    case 9: return get("EscapeAnalysisIterations");
                    case 10: return get("EscapeAnalysisLoopCutoff");
                    case 11: return get("EscapeAnalyzeOnly");
                    case 12: return get("FullUnroll");
                    case 13: return get("GCDebugStartCycle");
                    case 14: return get("GenLoopSafepoints");
                    case 15: return get("GeneratePIC");
                    case 16: return get("GuardPriorities");
                    case 17: return get("HotSpotPrintInlining");
                    case 18: return get("ImmutableCode");
                    case 19: return get("InlineEverything");
                    case 20: return get("InlineMegamorphicCalls");
                    case 21: return get("InlineMonomorphicCalls");
                    case 22: return get("InlinePolymorphicCalls");
                    case 23: return get("InlineVTableStubs");
                    case 24: return get("Intrinsify");
                    case 25: return get("LimitInlinedInvokes");
                    case 26: return get("LoopHeaderAlignment");
                    case 27: return get("LoopMaxUnswitch");
                    case 28: return get("LoopPeeling");
                    case 29: return get("LoopPredication");
                    case 30: return get("LoopPredicationMainPath");
                    case 31: return get("LoopUnswitch");
                    case 32: return get("MatchExpressions");
                    case 33: return get("MaximumDesiredSize");
                    case 34: return get("MaximumEscapeAnalysisArrayLength");
                    case 35: return get("MaximumInliningSize");
                    case 36: return get("MaximumRecursiveInlining");
                    case 37: return get("MegamorphicInliningMinMethodProbability");
                    case 38: return get("MinimalBulkZeroingSize");
                    case 39: return get("MinimumPeelFrequency");
                    case 40: return get("OmitHotExceptionStacktrace");
                    case 41: return get("OptAssumptions");
                    case 42: return get("OptConvertDeoptsToGuards");
                    case 43: return get("OptDeoptimizationGrouping");
                    case 44: return get("OptDevirtualizeInvokesOptimistically");
                    case 45: return get("OptEliminateGuards");
                    case 46: return get("OptFloatingReads");
                    case 47: return get("OptImplicitNullChecks");
                    case 48: return get("OptReadElimination");
                    case 49: return get("OptScheduleOutOfLoops");
                    case 50: return get("PartialEscapeAnalysis");
                    case 51: return get("PartialUnroll");
                    case 52: return get("PrintProfilingInformation");
                    case 53: return get("RawConditionalElimination");
                    case 54: return get("ReadEliminationMaxLoopVisits");
                    case 55: return get("ReassociateExpressions");
                    case 56: return get("RegisterPressure");
                    case 57: return get("RemoveNeverExecutedCode");
                    case 58: return get("ReplaceInputsWithConstantsBasedOnStamps");
                    case 59: return get("SmallCompiledLowLevelGraphSize");
                    case 60: return get("SnippetCounters");
                    case 61: return get("StressExplicitExceptionCode");
                    case 62: return get("StressInvokeWithExceptionNode");
                    case 63: return get("StressTestEarlyReads");
                    case 64: return get("StringIndexOfLimit");
                    case 65: return get("SupportJsrBytecodes");
                    case 66: return get("TraceEscapeAnalysis");
                    case 67: return get("TraceInlining");
                    case 68: return get("TraceInliningForStubsAndSnippets");
                    case 69: return get("TrackNodeInsertion");
                    case 70: return get("TrackNodeSourcePosition");
                    case 71: return get("TrivialInliningSize");
                    case 72: return get("UseEncodedGraphs");
                    case 73: return get("UseExceptionProbability");
                    case 74: return get("UseGraalStubs");
                    case 75: return get("UseLoopLimitChecks");
                    case 76: return get("UseSnippetGraphCache");
                    case 77: return get("UseTypeCheckHints");
                    case 78: return get("VerifyHeapAtReturn");
                    case 79: return get("VerifyPhases");
                    case 80: return get("ZapStackOnMethodEntry");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
