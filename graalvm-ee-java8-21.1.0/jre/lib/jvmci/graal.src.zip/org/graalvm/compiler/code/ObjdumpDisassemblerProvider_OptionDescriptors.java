// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: ObjdumpDisassemblerProvider.java
package org.graalvm.compiler.code;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class ObjdumpDisassemblerProvider_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "ObjdumpExecutables": {
            return OptionDescriptor.create(
                /*name*/ "ObjdumpExecutables",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ String.class,
                /*help*/ "Comma separated list of candidate GNU objdump executables. If not specified, disassembling via GNU objdump is disabled. Otherwise, the first existing executable in the list is used.",
                /*declaringClass*/ ObjdumpDisassemblerProvider.Options.class,
                /*fieldName*/ "ObjdumpExecutables",
                /*option*/ ObjdumpDisassemblerProvider.Options.ObjdumpExecutables,
                /*deprecated*/ false);
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<OptionDescriptor>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("ObjdumpExecutables");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
